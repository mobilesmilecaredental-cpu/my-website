# Smile Care — website files

Everything in this folder is the complete website. No build step, no
installs, no server code. Upload the folder as-is.

## What's here

    index.html          Home page
    care-homes.html     Long-term care & retirement homes page
    support.js          Required — do not delete or rename
    assets/             Logo, QR code, photos

## Before you publish: turn on the inquiry form (2 minutes)

Out of the box, the contact forms open the visitor's own email app.
That's unreliable — some people have no mail app set up. To have
submissions land in your inbox automatically:

1. Go to **https://web3forms.com**
2. Enter **mobilesmilecaredental@gmail.com** and submit
3. They email you an **access key** (looks like `a1b2c3d4-e5f6-...`)
4. Open `index.html` in any text editor (Notepad, TextEdit)
5. Near the top, find this line:

       window.SMILE_CARE_FORM_KEY = "";

6. Paste your key between the quotes and save:

       window.SMILE_CARE_FORM_KEY = "a1b2c3d4-e5f6-...";

7. Do the exact same thing in `care-homes.html`

Both forms now send straight to your Gmail. Free tier covers 250
submissions per month.

## Publishing (Netlify — easiest, free)

1. Go to **https://app.netlify.com/drop**
2. Drag this entire folder onto the page
3. It's live immediately on a temporary address like
   `random-name-123.netlify.app`
4. Test both forms and every link

### Connecting your own domain

1. Buy a domain — **Cloudflare Registrar** is cheapest (~$10–12/yr)
   at cloudflare.com, or Namecheap
2. In Netlify: **Site settings → Domain management → Add a domain**
3. Netlify shows you two nameservers — enter those at your registrar
4. Wait up to a few hours for it to take effect. HTTPS is automatic.

## Making changes later

Text and colours are plain HTML inside the two files, editable in any
text editor. To swap a photo, replace the file in `assets/` keeping
the same filename. After any edit, re-drag the folder onto Netlify to
update the live site.

## Notes

- Test on a real phone before sharing the link widely.
- The pages are one file each — nothing else to configure.
- Keep a copy of this folder somewhere safe as your master version.
